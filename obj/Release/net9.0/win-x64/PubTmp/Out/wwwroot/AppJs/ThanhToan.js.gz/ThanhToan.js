﻿successAction = function (res) {
    debugger;
    if (res.success) {
        UnBlockUI();
        alert(res.message);
        window.location.href = "/Home"
    }
    else {
        UnBlockUI();
        alert(res.message);
    }
}
