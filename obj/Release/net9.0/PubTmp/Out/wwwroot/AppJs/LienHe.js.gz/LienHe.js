﻿successAction = function (res) {
    debugger;
    if (res.success) {
        UnBlockUI();
        alert(res.message);
        location.reload();
    }
    else {
        UnBlockUI();
        alert(res.message);
    }
}
